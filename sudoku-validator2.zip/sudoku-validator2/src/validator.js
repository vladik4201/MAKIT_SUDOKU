class Validator {
  static validate(sudoku) {
    const validator = new Validator

    return validator.validate(sudoku)
  }

  validate(sudoku) {
   let data = sudoku.split(/[|\n\s]/)
    for(let i = data.length; i--;){
        if(data[i].length != 1) {
            data.splice(i,1)
        }

    }
//    console.log(data.length)
//    console.log(data)
      let row = horizontalArrayToRows(data,9)
//      console.log(row)

//      console.log("Sudoku is valid.")
      var is_valid_or_incomplete = columnsCheck(row)
        if(is_valid_or_incomplete == true){
            console.log("Sudoku is valid but incomplete.")
        }
        else{
           var valid_or_not_row = ValidRow(data)
           var valid_or_not_column = ValidRow(ColumnSplit(data))
           var valid_or_not_grids = GridValidator(row)
               if((valid_or_not_row == true)&&(valid_or_not_column == true)&&(valid_or_not_grids == true)){
               console.log("Sudoku is valid.")
             }
             else{
             console.log("Sudoku is invalid.")
             }
        }
       }
   }

function horizontalArrayToRows(array, elements) {
    var matrix = [], i, k;
    for (i = 0, k = -1; i < array.length; i++) {
        if (i % elements === 0) {
            k++;
            matrix[k] = [];
        }

        matrix[k].push(array[i]);
    }

    return matrix;
}



module.exports = Validator



function columnsCheck(row, rowchecker) {
    for ( y = 0; y < row.length; y++ ){ // first dimension for loop
        for(x = 0; x < row[y].length; x++){ // 2nd dimension for loop
            if(rowchecker == row[y][x]){
            return true

            }
        }
    }
    return false
}

function GridValidator(grid){
    let temp = 0;
    for( y = 0; y <  grid.length; y++){
    temp = 0;
        for(p = 0; p < grid[y].length; p++){
        temp += grid[y][p]
    }
    if (temp != 45)
    return false
    }
return true

}

function ValidRow(OneDarray){
    for(l = 0; l < 9; l++){
        let temp = 0;
        for(k = 0; k < 9; k++){
            temp += OneDarray[l * 8 + k]
        }
        if(temp != 45){
        return false
        }
    }
    return true
}

function ColumnSplit(column){
    let columns = [];
    for(y = 0; y < 9; y++){
    columns.push(column[y])
    columns.push(column[y + 9])
    columns.push(column[y + 18])
    columns.push(column[y + 27])
    columns.push(column[y + 36])
    columns.push(column[y + 45])
    columns.push(column[y + 52])
    columns.push(column[y + 63])
    columns.push(column[y + 72])

    }
return columns
}





